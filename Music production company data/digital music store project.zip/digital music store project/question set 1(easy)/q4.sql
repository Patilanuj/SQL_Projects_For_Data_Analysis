/*Q4: Which city has the best customers? We would like to throw a promotional music festival in the city we made the
most money.Write a query that returns once city that has the highest sum of invoice totals.Return both the city name
and sum of all invoice totals.*/
select billing_city,sum(total) as totals
from invoice
group by billing_city
order by totals desc
limit 1;