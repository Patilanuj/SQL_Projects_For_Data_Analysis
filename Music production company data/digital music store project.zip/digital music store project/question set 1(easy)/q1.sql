/*Q2: Which countries have the most invoices?*/
select count(*) as invoices,billing_country from invoice
group by billing_country
order by invoices desc;
