/*Q5: Who is the best customer? The customer who has spent the most money will be declared as the best customer.
Write a query that returns the person who has spent most money.*/
select customer.customer_id, customer.first_name, customer.last_name, sum(invoice.total) as totals
from customer
inner join invoice on customer.customer_id = invoice.customer_id
group by customer.customer_id
order by totals desc
limit 1;