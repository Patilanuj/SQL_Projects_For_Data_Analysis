/*Q1: Write a query to return the email,first name,last name and genre of all rock music listeners.Return the list 
ordered alphabetically email starting A.
select first_name,last_name,email*/ 
select distinct email,first_name,last_name
from customer
join invoice on customer.customer_id = invoice.customer_id
join invoice_line on invoice.invoice_id = invoice_line.invoice_id
where track_id in(
select track.track_id from track
join genre on track.genre_id = genre.genre_id
	where genre.name like 'Rock'
)
order by email