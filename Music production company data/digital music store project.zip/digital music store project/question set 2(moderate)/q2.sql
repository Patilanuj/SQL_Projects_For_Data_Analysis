/*q2: Let's invite the artists who has written the most rock music in our dataset.Write a query that returns artist name and total track count of top 
10 rock bands.*/
select artist.artist_id,artist.name,count(artist.artist_id) as no_of_songs
from track
join album on track.album_id = album.album_id
join artist on album.artist_id = artist.artist_id
join genre on track.genre_id = genre.genre_id
where genre.name like 'Rock'
group by artist.artist_id
order by no_of_songs desc
limit 10;