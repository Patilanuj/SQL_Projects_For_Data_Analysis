/*q3: Return all the track names that have a song length longer than the average song length.Return the name and milliseconds for each track.order by
song length with the longest songs listed first.*/
select name, milliseconds
from track
where milliseconds > (
	select avg(milliseconds) as average_song_length
	from track)
order by milliseconds desc